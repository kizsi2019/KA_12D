var szam;
szam=10;

if(szam ==='10'){
    console.log('egyezik');
} else {
    console.log('nem egyezik')
}