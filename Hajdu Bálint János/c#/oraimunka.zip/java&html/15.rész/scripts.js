let körterülete =(r)=>{
    let pie= 3.14
    return pie*r*r
}
console.log(körterülete(13));