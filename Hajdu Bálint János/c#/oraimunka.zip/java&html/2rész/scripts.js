var keresztNev = 'Pisti';
var a =2
console.log(keresztNev);
var vezetekNev = 'Kis'
console.log(vezetekNev);

var kor =32;
console.log(kor);

var nagykoru=false;
console.log(nagykoru);

var magassag;
console.log(magassag)