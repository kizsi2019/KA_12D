var keresztNev='Pisti';
var kor=32;

console.log(keresztNev+''+kor)

var VezetekNev , felnott;
VezetekNev='Kovacs'

console.log(VezetekNev + 'felnőtt?'+felnott);
kor='harminc';