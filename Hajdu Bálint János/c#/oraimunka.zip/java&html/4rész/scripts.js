var szam=10;
var osszeg = szam+33;
console.log(osszeg);
var kulonbség=100-szam;
console.log(kulonbség);

console.log(szam * 2 );
console.log(szam / 3 );

var szam1=100;
var szam2=100;
var egyenlo=szam1==szam2;
console.log(egyenlo);

