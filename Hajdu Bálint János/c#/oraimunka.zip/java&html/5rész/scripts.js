const nev = {
    kereszt:'Pisti',
    vezetek:'Kis'
};

Nev={
    kereszt:Pisti , 
    vezetek:'kis'
}
