var fiu=23;
var lanyok =35;

if (fiuk>lanyok) {
    console.log('A fiuk vannak többen.');
} else {
    console.log('A lanyok vannak többen.');

}

var belaKora=54;
var felnott = true;

if(felnott){
    console.log('Béla már felnött.');
}else{
    console.log('Béla még kölyök.')
}