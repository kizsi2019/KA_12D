var sutANap = false;
var joidVan=true;

if (sutANap !=false || joidVan !=false){
    console.log('Jó kedvem van');

} else {
    console.log('rossz kedvem van ');

}